import ee
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import rasterio
from pathlib import Path
from tqdm import tqdm

#############################################
# 1. Earth Engine Authentication & Initialization
#############################################
ee.Authenticate()
ee.Initialize(project='ee-vilaparthi')  # Replace with your project if needed

#############################################
# 2. CONFIGURATION & DATA LOADING
#############################################
INPUT_FILE = "butterfly.csv"  # Your full dataset
OUTPUT_FILE = "butterfly_final_backfilled.csv"  # Final output file
RASTER_DIR = Path("esp_rasters")  # Folder with TIFF files
AVAILABLE_YEARS = list(range(2000, 2019))  # 2000 to 2018

# Load the dataset
df = pd.read_csv(INPUT_FILE)
df['year'] = df['year'].astype(int)
df['month'] = df['month'].astype(int)
# Round coordinates to 5 decimals for robust grouping
df['decimalLatitude'] = df['decimalLatitude'].round(5)
df['decimalLongitude'] = df['decimalLongitude'].round(5)

# We'll update (replace) all records for years < 2000 using our new approach.
mask_pre2000 = df['year'] < 2000

#############################################
# 3. BATCH EXTRACTION OF NDVI FROM EARTH ENGINE
#############################################
# Get unique (lat, lon, month) combinations from records with year >=2000.
unique_points = df[df['year'] >= 2000][['decimalLatitude', 'decimalLongitude', 'month']].drop_duplicates()


def create_feature(lat, lon, month, year):
    """Create an EE Feature for a given location and month/year using the 15th as reference date."""
    date = datetime(year, month, 15)
    start = date - timedelta(days=8)
    end = date + timedelta(days=8)
    return ee.Feature(ee.Geometry.Point([lon, lat]), {
        'month': month,
        'year': year,
        'start': start.strftime('%Y-%m-%d'),
        'end': end.strftime('%Y-%m-%d')
    })


ndvi_results = {}  # key: (lat, lon, month, year), value: NDVI

print("Preprocessing NDVI values from Earth Engine...")
for yr in AVAILABLE_YEARS:
    features = []
    for _, row in unique_points.iterrows():
        lat = row['decimalLatitude']
        lon = row['decimalLongitude']
        month = int(row['month'])
        features.append(create_feature(lat, lon, month, yr))
    fc = ee.FeatureCollection(features)

    # Get the date range from the first feature.
    sample = fc.first().get('start').getInfo()
    start_date = sample
    sample = fc.first().get('end').getInfo()
    end_date = sample

    # Query the MODIS NDVI collection (MOD13Q1) for the date range.
    collection = (ee.ImageCollection("MODIS/006/MOD13Q1")
                  .filterBounds(fc)
                  .filterDate(start_date, end_date)
                  .median()
                  .select('NDVI'))

    # Use reduceRegions to extract NDVI values in one request.
    reduced = collection.reduceRegions(collection=fc, reducer=ee.Reducer.mean(), scale=250)
    result = reduced.getInfo()  # Single HTTP request per year.

    for f in result['features']:
        props = f['properties']
        coords = f['geometry']['coordinates']  # [lon, lat]
        key = (round(coords[1], 5), round(coords[0], 5), int(props['month']), yr)
        ndvi_val = props.get('mean', None)
        if ndvi_val is not None:
            # MODIS NDVI is scaled by 0.0001.
            ndvi_results[key] = ndvi_val * 0.0001

#############################################
# 4. BATCH EXTRACTION OF POPULATION DENSITY FROM TIFFs (Vectorized)
#############################################
print("Loading Population Density TIFFs into memory (batch processing)...")
pop_data = {}  # key: year, value: (numpy array, transform)
for yr in AVAILABLE_YEARS:
    raster_path = RASTER_DIR / f'esp_ppp_{yr}_UNadj.tif'
    if not raster_path.exists():
        print(f"⚠️ TIFF file for year {yr} not found.")
        continue
    with rasterio.open(raster_path) as src:
        arr = src.read(1)  # Load entire raster into memory
        transform = src.transform
    pop_data[yr] = (arr, transform)
    print(f"✅ Population data for year {yr} loaded.")


def get_pop_value(lat, lon, yr):
    if yr not in pop_data:
        return None
    arr, transform = pop_data[yr]
    try:
        row, col = rasterio.transform.rowcol(transform, lon, lat)
        return float(arr[row, col])
    except Exception:
        return None


# Build dictionary of population values for each unique (lat, lon, month) for years 2000–2018.
pop_results = {}  # key: (lat, lon, month, year), value: population density
print("Batch extracting Population Density values...")
for yr in AVAILABLE_YEARS:
    for _, row in unique_points.iterrows():
        lat = row['decimalLatitude']
        lon = row['decimalLongitude']
        month = int(row['month'])  # Even though population is annual, we keep month for grouping.
        pop_val = get_pop_value(lat, lon, yr)
        if pop_val is not None:
            key = (lat, lon, month, yr)
            pop_results[key] = pop_val
    print(f"✅ Completed processing population density for year {yr}.")


#############################################
# 5. TIME-AWARE INTERPOLATION FOR PRE-2000 RECORDS
#############################################
def interpolate_value(target_time, time_list, value_list):
    return np.interp(target_time, time_list, value_list)


ndvi_updates = 0
pop_updates = 0

print("Interpolating values for pre-2000 records...")
for idx, row in tqdm(df[mask_pre2000].iterrows(), total=mask_pre2000.sum(), desc="Backfilling pre-2000"):
    lat = row['decimalLatitude']
    lon = row['decimalLongitude']
    month = int(row['month'])
    target_year = int(row['year'])
    target_time = target_year + (month - 1) / 12.0  # Continuous time

    # --- NDVI Interpolation ---
    ndvi_years = []
    ndvi_values = []
    for yr in AVAILABLE_YEARS:
        key = (lat, lon, month, yr)
        if key in ndvi_results:
            t = yr + (month - 1) / 12.0  # For same month in that year.
            ndvi_years.append(t)
            ndvi_values.append(ndvi_results[key])
    if len(ndvi_years) >= 2:
        new_ndvi = interpolate_value(target_time, ndvi_years, ndvi_values)
        df.at[idx, 'ndvi'] = new_ndvi
        ndvi_updates += 1

    # --- Population Density Interpolation ---
    pop_years = []
    pop_values = []
    for yr in AVAILABLE_YEARS:
        key = (lat, lon, month, yr)
        if key in pop_results:
            pop_years.append(yr)  # Use integer year for population.
            pop_values.append(pop_results[key])
    if len(pop_years) >= 2:
        new_pop = np.interp(target_year, pop_years, pop_values)
        df.at[idx, 'pop_density_monthly'] = new_pop
        pop_updates += 1

#############################################
# 6. SAVE FINAL FILE & PRINT SUMMARY
#############################################
df.to_csv(OUTPUT_FILE, index=False)
total_pre2000 = mask_pre2000.sum()
print(f"✅ NDVI backfilled for {ndvi_updates} out of {total_pre2000} pre-2000 rows.")
print(f"✅ Population density backfilled for {pop_updates} out of {total_pre2000} pre-2000 rows.")
print(f"✅ Final file saved as: {OUTPUT_FILE}")
