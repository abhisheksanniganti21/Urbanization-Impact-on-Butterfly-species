# import pandas as pd
# import numpy as np
#
# # ----- CONFIGURATION -----
# INPUT_FILE = "butterfly_final_backfilled.csv"  # File with previously backfilled data (pre-2000 filled by the previous approach)
# OUTPUT_FILE = "butterfly_fully_filled.csv"       # Final output file with all missing values filled
# # -------------------------
#
# # Load the dataset
# df = pd.read_csv(INPUT_FILE)
#
# # Ensure required columns exist and are in proper type
# required_cols = ['decimalLatitude', 'decimalLongitude', 'year', 'month', 'ndvi', 'pop_density_monthly']
# for col in required_cols:
#     if col not in df.columns:
#         raise ValueError(f"Missing required column: {col}")
#
# df['year'] = df['year'].astype(int)
# df['month'] = df['month'].astype(int)
#
# # Round coordinates to 5 decimals for consistent grouping
# df['decimalLatitude'] = df['decimalLatitude'].round(5)
# df['decimalLongitude'] = df['decimalLongitude'].round(5)
#
# # Create a continuous time variable for interpolation: year + (month-1)/12
# df['time'] = df['year'] + (df['month'] - 1) / 12.0
#
# # Define a function that fills missing values within a group (using interpolation first, then linear regression)
# def fill_missing_by_group(group, col):
#     # Sort group by time
#     group = group.sort_values('time')
#     # First, use pandas linear interpolation with limit_direction 'both'
#     group[col] = group[col].interpolate(method='linear', limit_direction='both')
#     # If there are still missing values and at least 2 known points, use linear regression (np.polyfit)
#     if group[col].isna().sum() > 0 and group[col].notna().sum() >= 2:
#         known = group[group[col].notna()]
#         times = known['time'].values
#         values = known[col].values
#         # Fit a simple linear regression (y = m*x + b)
#         m, b = np.polyfit(times, values, 1)
#         # For each missing value, predict it using the regression model
#         for idx in group[group[col].isna()].index:
#             t_val = group.at[idx, 'time']
#             group.at[idx, col] = m * t_val + b
#     return group
#
# # Group by location (latitude, longitude) and month
# group_keys = ['decimalLatitude', 'decimalLongitude', 'month']
#
# # Count missing values before filling (for reporting)
# missing_before_ndvi = df['ndvi'].isna().sum()
# missing_before_pop = df['pop_density_monthly'].isna().sum()
#
# # Apply the filling function to NDVI and pop_density_monthly columns
# df_filled = df.groupby(group_keys, group_keys=False).apply(lambda g: fill_missing_by_group(g, 'ndvi'))
# df_filled = df_filled.groupby(group_keys, group_keys=False).apply(lambda g: fill_missing_by_group(g, 'pop_density_monthly'))
#
# # Count missing values after filling
# missing_after_ndvi = df_filled['ndvi'].isna().sum()
# missing_after_pop = df_filled['pop_density_monthly'].isna().sum()
#
# # Save final dataset
# df_filled.drop(columns=['time'], inplace=True)
# df_filled.to_csv(OUTPUT_FILE, index=False)
#
# print(f"✅ NDVI missing values before filling: {missing_before_ndvi}")
# print(f"✅ NDVI missing values after filling: {missing_after_ndvi}")
# print(f"✅ Population density missing values before filling: {missing_before_pop}")
# print(f"✅ Population density missing values after filling: {missing_after_pop}")
# print(f"✅ Final file saved as: {OUTPUT_FILE}")


import pandas as pd

# List of columns to keep
columns_to_keep = [
    "family",
    "species",
    "individualCount",
    "decimalLatitude",
    "decimalLongitude",
    "day",
    "month",
    "year",
    "temperature",
    "precipitation",
    "humidity",
    "wind",
    "pop_density_monthly",
    "ndvi",
    "elevation_m",
    "land_cover_class",
    "land_cover_label"
]

# Read the final dataset (adjust the file name if needed)
df = pd.read_csv("butterfly_final.csv")

# Select only the desired columns
df_subset = df[columns_to_keep]

# Save the resulting DataFrame as a new CSV file
output_csv = "final_dataset.csv"
df_subset.to_csv(output_csv, index=False)

print(f"✅ CSV file '{output_csv}' created with the specified columns.")

