import requests
import os
import re


def extract_year(filename):
    """
    Extract the first 4-digit number from the filename.
    Returns the year as an integer or None if no 4-digit number is found.
    """
    match = re.search(r'\d{4}', filename)
    if match:
        return int(match.group())
    return None


def download_file(url, base_folder="files"):
    """
    Downloads a file from a direct download URL.
    Extracts the year from the filename and saves the file in a subfolder named after the year.
    Only downloads files whose year is between 1984 and 2018 (inclusive).
    """
    # Extract filename from the URL; if not available, use a default name.
    filename = url.split("/")[-1] or "downloaded_file"

    # Extract the year from the filename
    year = extract_year(filename)
    if year is None:
        print(f"Could not determine year for {filename}. Skipping.")
        return
    if not (1984 <= year <= 2018):
        print(f"File {filename} with year {year} is not in the range 1984-2018. Skipping.")
        return

    # Create the destination folder as 'files/<year>'
    dest_folder = os.path.join(base_folder, str(year))
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)

    filepath = os.path.join(dest_folder, filename)

    try:
        # For direct download links, a simple get() is enough.
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for HTTP errors

        # Write the content directly to a file.
        with open(filepath, "wb") as f:
            f.write(response.content)
        print(f"Downloaded: {filename} into folder {dest_folder}")
    except Exception as e:
        print(f"Error downloading {url}: {e}")


def main():
    # Read URLs from Links.txt, one per line.
    try:
        with open("Links.txt", "r") as file:
            links = [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print("Links.txt not found!")
        return

    # Process each URL.
    for url in links:
        print(f"Processing: {url}")
        download_file(url)


if __name__ == "__main__":
    main()
