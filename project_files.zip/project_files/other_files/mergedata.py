import pandas as pd

# Load each CSV
df_temp    = pd.read_csv("butterfly_with_temperature.csv")
df_prec    = pd.read_csv("butterfly_with_precipitation.csv")
df_humwind = pd.read_csv("butterfly_with_humidity_wind.csv")

# Start from the temperature file (it already has all the “base” columns)
df = df_temp.set_index("gbifID")

# Join just the extra measurement columns from each of the others
df = df.join(df_prec.set_index("gbifID")[["precipitation"]], how="left")
df = df.join(df_humwind.set_index("gbifID")[["humidity", "wind"]], how="left")

# Move gbifID back into a column and save
df.reset_index().to_csv("butterfly_full_dataset.csv", index=False)
print("✅ butterfly_full_dataset.csv created with temperature, precipitation, humidity, and wind")
